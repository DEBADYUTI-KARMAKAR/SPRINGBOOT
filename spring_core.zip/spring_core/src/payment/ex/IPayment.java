package payment.ex;

public interface IPayment {
    public boolean processPayment(double billAmount);
}
